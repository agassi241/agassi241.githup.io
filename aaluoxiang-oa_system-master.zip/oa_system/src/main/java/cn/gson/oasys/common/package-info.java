
/**
 * 整个工程所使用到的公共类
 * @author luoxiang
 *
 */
package cn.gson.oasys.common;