/**
 * 
 */
/**任务实体类
 * @author 宋妈
 *
 */
package cn.gson.oasys.model.entity.task;