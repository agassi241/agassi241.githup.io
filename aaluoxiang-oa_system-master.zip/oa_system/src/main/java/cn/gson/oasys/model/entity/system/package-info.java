
/**
 * 系统模块
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.entity.system;