function toyellow(){
	/* 绿变黄 */
	$('.green').removeClass('green').addClass('yellow');
	$('.green-g').removeClass('green-g').addClass('yellow-y');
	$('.green-none').removeClass('green-none').addClass('yellow-none');
	$('.green-left').removeClass('green-left').addClass('yellow-left');
	$('.green-box').removeClass('green-box').addClass('yellow-box');
	/*蓝变黄  */
	$('.blue').removeClass('blue').addClass('yellow');
	$('.blue-b').removeClass('blue-b').addClass('yellow-y');
	$('.blue-none').removeClass('blue-none').addClass('yellow-none');
	$('.blue-left').removeClass('blue-left').addClass('yellow-left');
	$('.blue-box').removeClass('blue-box').addClass('yellow-box');
	/* 红变黄 */
	$('.red').removeClass('red').addClass('yellow');
	$('.red-r').removeClass('red-r').addClass('yellow-y');
	$('.red-none').removeClass('red-none').addClass('yellow-none');
	$('.red-left').removeClass('red-left').addClass('yellow-left');
	$('.red-box').removeClass('red-box').addClass('yellow-box');
}
function toblue(){
	/* 绿变黄 */
	$('.green').removeClass('green').addClass('blue');
	$('.green-g').removeClass('green-g').addClass('blue-b');
	$('.green-none').removeClass('green-none').addClass('blue-none');
	$('.green-left').removeClass('green-left').addClass('blue-left');
	$('.green-box').removeClass('green-box').addClass('blue-box');
	/* 红变黄 */
	$('.red').removeClass('red').addClass('blue');
	$('.red-r').removeClass('red-r').addClass('blue-b');
	$('.red-none').removeClass('red-none').addClass('blue-none');
	$('.red-left').removeClass('red-left').addClass('blue-left');
	$('.red-box').removeClass('red-box').addClass('blue-box');
	/* 红变黄 */
	$('.yellow').removeClass('yellow').addClass('blue');
	$('.yellow-y').removeClass('yellow-y').addClass('blue-b');
	$('.yellow-none').removeClass('yellow-none').addClass('blue-none');
	$('.yellow-left').removeClass('yellow-left').addClass('blue-left');
	$('.yellow-box').removeClass('yellow-box').addClass('blue-box');
}
function tored(){
	/* 绿变黄 */
	$('.green').removeClass('green').addClass('red');
	$('.green-g').removeClass('green-g').addClass('red-r');
	$('.green-none').removeClass('green-none').addClass('red-none');
	$('.green-left').removeClass('green-left').addClass('red-left');
	$('.green-box').removeClass('green-box').addClass('red-box');
	/*蓝变黄  */
	$('.blue').removeClass('blue').addClass('red');
	$('.blue-b').removeClass('blue-b').addClass('red-r');
	$('.blue-none').removeClass('blue-none').addClass('red-none');
	$('.blue-left').removeClass('blue-left').addClass('red-left');
	$('.blue-box').removeClass('blue-box').addClass('red-box');
	/* 红变黄 */
	$('.yellow').removeClass('yellow').addClass('red');
	$('.yellow-y').removeClass('yellow-y').addClass('red-r');
	$('.yellow-none').removeClass('yellow-none').addClass('red-none');
	$('.yellow-left').removeClass('yellow-left').addClass('red-left');
	$('.yellow-box').removeClass('yellow-box').addClass('red-box');
}
function togreen(){
	/*蓝变黄  */
	$('.blue').removeClass('blue').addClass('green');
	$('.blue-b').removeClass('blue-b').addClass('green-g');
	$('.blue-none').removeClass('blue-none').addClass('green-none');
	$('.blue-left').removeClass('blue-left').addClass('green-left');
	$('.blue-box').removeClass('blue-box').addClass('green-box');
	/* 红变黄 */
	$('.red').removeClass('red').addClass('green');
	$('.red-r').removeClass('red-r').addClass('green-g');
	$('.red-none').removeClass('red-none').addClass('green-none');
	$('.red-left').removeClass('red-left').addClass('green-left');
	$('.red-box').removeClass('red-box').addClass('green-box');
	/* 红变黄 */
	$('.yellow').removeClass('yellow').addClass('green');
	$('.yellow-y').removeClass('yellow-y').addClass('green-g');
	$('.yellow-none').removeClass('yellow-none').addClass('green-none');
	$('.yellow-left').removeClass('yellow-left').addClass('green-left');
	$('.yellow-box').removeClass('yellow-box').addClass('green-box');
}
