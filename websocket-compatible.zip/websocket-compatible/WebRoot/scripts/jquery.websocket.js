;(function ($) {
    $.websocket = function (options) {
        var defaults = {
            domain: top.location.hostname,
            port: 8080
        };
        var opts = $.extend(defaults, options);
        var szServer = "ws://" + opts.domain + ":" + opts.port + "/" + opts.protocol;
        var socket = undefined;
        var bOpen = false;
        var t1 = 0;
        var t2 = 0;
        var messageevent = {
            onInit: function () {
                if (!("WebSocket" in window) && !("MozWebSocket" in window)) {
                    return false;
                }
                if (("MozWebSocket" in window)) {
                    socket = new MozWebSocket(szServer);
                } else {
                    socket = new WebSocket(szServer);
                }
                if (opts.onInit) {
                    opts.onInit();
                }
            },
            onOpen: function (event) {
                bOpen = true;
                if (opts.onOpen) {
                    opts.onOpen(event);
                }
            },
            onSend: function (msg) {
                t1 = new Date().getTime();
                if (opts.onSend) {
                    opts.onSend(msg);
                }
                socket.send(msg);
            },
            onMessage: function (msg) {
                t2 = new Date().getTime();
                if (opts.onMessage) {
                    opts.onMessage(msg.data, t2 - t1);
                }
            },
            onError: function (event) {
                if (opts.onError) {
                    opts.onError(event);
                }
            },
            onClose: function (event) {
                if (opts.onClose) {
                    opts.onClose(event);
                }
                socket.close();
            }
        };
        messageevent.onInit();
        socket.onopen = messageevent.onOpen;
        socket.onmessage = messageevent.onMessage;
        socket.onerror = messageevent.onError;
        socket.onclose = messageevent.onClose;
        this.send = function (pData) {
            if (bOpen == false) {
                return false;
            }
            messageevent.onSend(pData);
            return true;
        };
        this.close = function () {
            messageevent.onClose();
        };
        this.socket = socket;
        return this;
    };
})(jQuery);
