环境要求及搭建方法:
    1.Tomcat要求为7.0.27以上的版本,jdk1.6以上,另外Tomcat7.0.27版本,20秒如果不发送消息,就会掉线
    2.需要在工程中引入tomcat中lib下面三个jar包:catalina.jar, tomcat-coyote.jar, servlet-api.jar及Gson.jar.
    3.解决兼容低版本IE的思路:判断当前浏览器是否原生支持websocket,如果不支持,
      就使用flash(web-socket-js判断浏览器是否支持webSocket协议).

可能出现问题及解决方法:
    java.lang.NoSuchMethodException: org.apache.catalina.deploy.WebXml addServlet
        解决方法:Tomcat安装文件context.xml里的Context标签中添加 <Loader delegate="true" /> 即可解决该问题.
