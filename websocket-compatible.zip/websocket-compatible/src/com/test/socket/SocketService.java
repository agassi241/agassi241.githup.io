package com.test.socket;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 这个socket主要还是为了flash的socket
 */
public class SocketService {

    private ServerSocket serverSocket = null;

    private static Object locker = new Object();

    // 线程池
    private static ExecutorService executorService = null;

    public synchronized void initSocketServer() {
        try {
            if (executorService == null) {
                executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 20);
            } else {
                return;
            }
            //启动843端口
            serverSocket = new ServerSocket(843);
            Runnable runnable = new Server();
            Thread thread = new Thread(runnable);
            thread.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeServer() {
        locker = null;
        if (serverSocket != null && !serverSocket.isClosed()) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class Server implements Runnable {
        @Override
        public void run() {
            try {
                while (locker != null) {
                    if (serverSocket == null || serverSocket.isClosed()) {
                        continue;
                    }
                    //接收客户端的连接
                    Socket incoming = serverSocket.accept();
                    Runnable runnable = new ThreadClient(incoming);
                    executorService.execute(runnable);
                }
            } catch (Exception e) {
                //此处有一种异常，当关掉Tomcat时，会去关闭ServerSocket对象，
                //从而抛出异常java.net.SocketException: socket closed，
                //原因是ServerSocket对象正在等待客户端连接或正在连接中
                e.printStackTrace();
            }
        }
    }

    class ThreadClient implements Runnable {

        private Socket incoming;

        private ThreadClient(Socket socket) {
            incoming = socket;
        }

        public void run() {
            InputStreamReader isr = null;
            BufferedReader br = null;
            OutputStreamWriter osw = null;
            BufferedWriter bw = null;
            try {
                isr = new InputStreamReader(incoming.getInputStream(), "UTF-8");
                br = new BufferedReader(isr);
                osw = new OutputStreamWriter(incoming.getOutputStream(), "UTF-8");
                bw = new BufferedWriter(osw);
                //读取客户端发送的数据
                StringBuilder sb = new StringBuilder();
                int c;
                while ((c = br.read()) != -1) {
                    if (c != '\0') {
                        sb.append((char) c);
                    } else {
                        break;
                    }
                }
                String info = sb.toString();
                System.out.println(String.format("客户端发送的数据:%s", info));
                //接收到客户端请求之后，将策略文件发送出去
                if (info.contains("<policy-file-request/>")) {
                    bw.write("<cross-domain-policy><site-control permitted-cross-domain-policies=\"all\"/><allow-access-from domain=\"*\" to-ports=\"*\"/></cross-domain-policy>\0");
                    bw.flush();
                    System.out.println(String.format("将安全策略文件发送至:%s", incoming.getInetAddress()));
                } else {
                    bw.write("请求无法识别\0");
                    bw.flush();
                    System.out.println(String.format("请求无法识别:%s", incoming.getInetAddress()));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (br != null) {
                        br.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (isr != null) {
                        isr.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (bw != null) {
                        bw.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (osw != null) {
                        osw.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (incoming != null) {
                        incoming.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
