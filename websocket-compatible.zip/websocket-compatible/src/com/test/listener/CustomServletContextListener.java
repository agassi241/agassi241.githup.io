package com.test.listener;

import com.test.socket.SocketService;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class CustomServletContextListener implements ServletContextListener {

    private SocketService service;

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        service.closeServer();
    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        service = new SocketService();
        service.initSocketServer();
    }
}
