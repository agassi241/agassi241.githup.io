package com.test.servlet.websocket;

import com.google.gson.Gson;
import com.test.domain.WebMessage;
import org.apache.catalina.websocket.MessageInbound;
import org.apache.catalina.websocket.StreamInbound;
import org.apache.catalina.websocket.WebSocketServlet;
import org.apache.catalina.websocket.WsOutbound;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 消息处理
 */
public class CustomWebSocketServlet extends WebSocketServlet {

    private static final long serialVersionUID = -4973045184093530845L;

    private List<CustomMessageInbound> userSocketList = new ArrayList<>();

    private synchronized void addMessageInbound(CustomMessageInbound messageInbound) {
        userSocketList.add(messageInbound);
    }

    private synchronized void removeMessageInbound(CustomMessageInbound messageInbound) {
        userSocketList.remove(messageInbound);
    }

    //将消息发送给所有用户
    private void sendToAllMsg(WebMessage webMsg) {
        String jsonStr = new Gson().toJson(webMsg);
        for (CustomMessageInbound messageInbound : userSocketList) {
            try {
                CharBuffer buffer = CharBuffer.wrap(jsonStr);
                messageInbound.getWsOutbound().writeTextMessage(buffer);
            } catch (Exception e) {
                System.out.println(String.format("用户<%s>发送消息失败|消息体<%s>", messageInbound.getUsername(), jsonStr));
                e.printStackTrace();
            }
        }
    }

    //将消息发送给指定用户
    private void sendToUserMsg(WebMessage webMsg) {
        String jsonStr = new Gson().toJson(webMsg);
        for (CustomMessageInbound messageInbound : userSocketList) {
            if (messageInbound.getUserId().equals(webMsg.getUserId())) {
                try {
                    CharBuffer buffer = CharBuffer.wrap(jsonStr);
                    messageInbound.getWsOutbound().writeTextMessage(buffer);
                } catch (Exception e) {
                    System.out.println(String.format("用户<%s>发送消息失败|消息体<%s>", messageInbound.getUsername(), jsonStr));
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected StreamInbound createWebSocketInbound(String arg0, HttpServletRequest request) {
        Long userId = Long.parseLong(request.getParameter("userId"));
        String username = request.getParameter("username");
        String clientMark = request.getParameter("clientMark");
        WebMessage webMsg = new WebMessage();
        webMsg.setUserId(userId);
        webMsg.setUsername(username);
        webMsg.setClientMark(clientMark);
        webMsg.setType("3");
        sendToUserMsg(webMsg);
        return new CustomMessageInbound(userId, username, clientMark);
    }

    private class CustomMessageInbound extends MessageInbound {

        private Long userId;

        private String username;

        private String clientMark;

        private WsOutbound wsOutbound;

        public Long getUserId() {
            return userId;
        }

        public String getUsername() {
            return username;
        }

        public String getClientMark() {
            return clientMark;
        }

        private CustomMessageInbound(Long userId, String username, String clientMark) {
            this.userId = userId;
            this.username = username;
            this.clientMark = clientMark;
        }

        @Override
        protected void onOpen(WsOutbound wsOutbound) {
            this.wsOutbound = wsOutbound;
            addMessageInbound(this);
            System.out.println(String.format("用户<%s>打开WebSocket连接...", username));
        }

        @Override
        protected void onClose(int status) {
            removeMessageInbound(this);
            System.out.println(String.format("用户<%s>关闭WebSocket连接...", username));
        }

        @Override
        protected void onBinaryMessage(ByteBuffer message) throws IOException {
            throw new UnsupportedOperationException("Binary message not supported.");
        }

        @Override
        protected void onTextMessage(CharBuffer msgChar) throws IOException {
            WebMessage webMsg = new Gson().fromJson(msgChar.toString(), WebMessage.class);
            if (webMsg.getUserId() == null) {
                sendToAllMsg(webMsg);
            } else {
                sendToUserMsg(webMsg);
            }
        }
    }
}
