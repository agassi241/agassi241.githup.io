package cn.vs9.chat.servlet.websocket;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.websocket.MessageInbound;
import org.apache.catalina.websocket.StreamInbound;
import org.apache.catalina.websocket.WebSocketServlet;
import org.apache.catalina.websocket.WsOutbound;


 

/** 消息处理
 * @author 
 *
 */
public class ChatWebSocketServlet extends WebSocketServlet {
	private static final long serialVersionUID = 1L;
    private String message_to ; 
    private String message_me ; 

    private static final String GUEST_PREFIX = "";
    
    //记录所有在线用户
    private static Map< String , ChatMessageInbound> mmiList = 
    	new ConcurrentHashMap< String , ChatMessageInbound >();

    private final AtomicInteger connectionIds = new AtomicInteger(0);

	@Override
	protected StreamInbound createWebSocketInbound(String arg0,
			HttpServletRequest request) {
		  message_me = request.getParameter( "message_me" );
		  message_to = request.getParameter( "message_to" );
		  System.out.println("ChatMessageInbound:"+message_me);
		  return new ChatMessageInbound(connectionIds.incrementAndGet());
	}

    private  class ChatMessageInbound extends MessageInbound {

        private final String nickname;
        WsOutbound myoutbound;
		private String me = message_me ; 
	    private String to = message_to ; 

        private ChatMessageInbound(int id) {
            this.nickname = GUEST_PREFIX + id;
        }

        @Override
        protected void onOpen(WsOutbound outbound) {
            String message = String.format("* %s %s", nickname, "has joined.");
            System.out.println("message:"+message);
            this.myoutbound = outbound;
           // mmiList.put( me , this );
            mmiList.put( nickname , this );
            broadcast(message);
        }

        @Override
        protected void onClose(int status) {
            if( status == 1002 || status == 1000)
            {
            	mmiList.remove(this);
            }
        }

        @Override
        protected void onBinaryMessage(ByteBuffer message) throws IOException {
            throw new UnsupportedOperationException(
                    "Binary message not supported.");
        }

        @Override
        protected void onTextMessage(CharBuffer message) throws IOException {
            String filteredMessage = String.format("%s: %s",nickname,  message.toString() );
            //System.out.println("send:"+filteredMessage);
            broadcast(filteredMessage);//将消息发送给所有人
            //将消息发送给指定人
//            for ( String mmib : mmiList.keySet() ) {
//            	if ( !to.equals(mmib) )
//            		continue;
//            	try
//            	{
//            		CharBuffer buffer = CharBuffer.wrap(message);
//            		mmiList.get(mmib).myoutbound.writeTextMessage(buffer);
//            		mmiList.get(mmib).myoutbound.flush();
//            	}
//            	catch (Exception e) {
//            		continue;
//				}
//        		break;
//            }
        }

        //将消息发送给所有用户
        private void broadcast(String message) {
        	for ( String key : mmiList.keySet() ) {
        		CharBuffer buffer = CharBuffer.wrap(message);
        		try {
					mmiList.get(key).getWsOutbound().writeTextMessage(buffer);
				} catch (IOException e) {
					//e.printStackTrace();
				}
        	}
        }
    }


	
}